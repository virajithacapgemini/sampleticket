package com.cg.ticketmanagementsystemmvcspring.service;

import java.util.List;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;


public interface TechnicianService {

	public Technician add(Technician technician) ;
	public List<Technician> searchTechnicianByCategory(String techniciancategory) ;
	public List<Technician> showAlltechniciancategory() ;

}
