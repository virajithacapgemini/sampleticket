package com.cg.ticketmanagementsystemmvcspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ticketmanagementsystemmvcspring.dao.TicketDaoImpl;
import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.dto.Ticket;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;
@Service
@Transactional
public class TicketServiceImpl implements TicketService{
	@Autowired
	TicketDaoImpl dao;
	@Override
	public Ticket assignTicket(Ticket ticket, Technician technician) {
		// TODO Auto-generated method stub
		 ticket.setStatus("Approved");
			return dao.save(ticket);
	}

	@Override
	public Ticket searchticketBytId(int id) {
		// TODO Auto-generated method stub
		return dao.findticketById(id);

	}

	
	

}
