package com.cg.ticketmanagementsystemmvcspring.service;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.dto.Ticket;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;

public interface TicketService {
	public Ticket assignTicket(Ticket ticket,Technician technician) ;
	//List<Ticket> searchByticketId(int id) throws CategoryNotFoundException;

	public	Ticket searchticketBytId(int id) ;

}
