package com.cg.ticketmanagementsystemmvcspring.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ticketmanagementsystemmvcspring.dao.TechnicianDao;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;


@Service
@Transactional
public class TechnicianServiceImpl  implements TechnicianService {
	@Autowired
	private TechnicianDao dao;
	@Override
	public Technician add(Technician technician) {
		// TODO Auto-generated method stub
		return dao.save(technician);
	}

	@Override
	public List<Technician> searchTechnicianByCategory(String techniciancategory) {
		List<Technician> technicians=dao.findTechnicianByCategory(techniciancategory);
		return technicians;
	}

	@Override
	public List<Technician> showAlltechniciancategory() {
		// TODO Auto-generated method stub
		return dao.showAlltechniciancategory();
	}

	
}