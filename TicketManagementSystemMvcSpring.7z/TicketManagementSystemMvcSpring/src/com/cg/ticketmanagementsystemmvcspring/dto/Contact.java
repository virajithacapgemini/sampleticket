package com.cg.ticketmanagementsystemmvcspring.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="contactdb")
public class Contact {
	@Id
	@Column(name="email_id")
	private String emailId;
	@Column(name="mobile_number")
	private BigInteger mobileNumber;
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String emailId, BigInteger mobileNumber) {
		super();
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "Contact [emailId=" + emailId + ", mobileNumber=" + mobileNumber + "]";
	}


}
