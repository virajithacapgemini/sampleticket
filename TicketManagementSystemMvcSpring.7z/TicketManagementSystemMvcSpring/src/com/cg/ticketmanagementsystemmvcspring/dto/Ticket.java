package com.cg.ticketmanagementsystemmvcspring.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="ticketdb")
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ticket_id")
	private int id;
	@Column(name="category_name")
	private String categoryName;
	@Column(name="compliant")
	private String compliant;
	@Column(name="status")
	private String status;
	@Temporal(TemporalType.DATE)
	@Column(name="posted_date")
	private Date postedDate;
	/*@ManyToOne
	 @JoinColumn(name="tech_id")
	private Technician technic;
*/	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Ticket(int id, String categoryName, String compliant, String status, Date postedDate) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.compliant = compliant;
		this.status = status;
		this.postedDate = postedDate;
		//this.technic = technic;
		//, Technician technic
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCompliant() {
		return compliant;
	}
	public void setCompliant(String compliant) {
		this.compliant = compliant;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getPostedDate() {
		return postedDate;
	}
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", categoryName=" + categoryName + ", compliant=" + compliant + ", status=" + status
				+ ", postedDate=" + postedDate + "]";
	}
	
	/*public Technician getTechnic() {
		return technic;
	}
	public void setTechnic(Technician technic) {
		this.technic = technic;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", categoryName=" + categoryName + ", compliant=" + compliant + ", status=" + status
				+ ", postedDate=" + postedDate + ", technic=" + technic + "]";
	}*/
	
	
}


