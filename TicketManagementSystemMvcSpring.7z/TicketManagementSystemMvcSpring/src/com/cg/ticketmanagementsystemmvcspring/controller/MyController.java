package com.cg.ticketmanagementsystemmvcspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.dto.Ticket;
import com.cg.ticketmanagementsystemmvcspring.service.TechnicianService;
import com.cg.ticketmanagementsystemmvcspring.service.TicketService;


@Controller
public class MyController {
	@Autowired
	TechnicianService technicianService;
	@Autowired
	TicketService ticketService;
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";
	}
	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		//System.out.println("checklogin...");
		if(user.equals("admin") && pass.equals("123456")) 
			return "listpage";
		
		else
		
			return "error";
		}
	@GetMapping("addpage")
	public ModelAndView getAddTechnician(@ModelAttribute("tech")Technician technicianone ) {
		return new ModelAndView("addtechnician");
	}
	@PostMapping("addtechnician")
	public ModelAndView addTechnician(@ModelAttribute("tech") Technician technicianone) {
		
		Technician technician=technicianService.add(technicianone);
		return new ModelAndView("success","key",technician);
			

}
	@GetMapping("showpage")
	public ModelAndView showProduct() {
		List<Technician> myAlltechniciancategory=technicianService.showAlltechniciancategory();
		return new ModelAndView("showtechniciancategory", "keyone", myAlltechniciancategory);
	}
	
	@GetMapping("searchpage")
	public ModelAndView getSearch(@ModelAttribute("tech") Technician technicianone) {
		return new ModelAndView("search"); 
	
}
@PostMapping("searchcategory")
public ModelAndView getSearchOne(@ModelAttribute("tech") Technician technicianone) {
	List<Technician> techniciancategorylist=technicianService.searchTechnicianByCategory(technicianone.getTechnicianCategory());
	return new ModelAndView("retrieve","keyone",techniciancategorylist);
	
	
}
/*
@GetMapping("assignpage")
public ModelAndView getasignTicket(@ModelAttribute("tiket") Ticket ticket,Technician technician) {
	return new ModelAndView("ticketpage");
}
@PostMapping("ticketpage")
public ModelAndView getassignTicket(ModelAndView model,@ModelAttribute("tiket")Ticket ticket) {
	
return 
}*/
}