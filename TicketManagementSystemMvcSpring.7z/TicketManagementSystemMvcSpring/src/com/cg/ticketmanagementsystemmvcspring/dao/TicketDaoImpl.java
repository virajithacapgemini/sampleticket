package com.cg.ticketmanagementsystemmvcspring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.dto.Ticket;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;

@Repository
public class TicketDaoImpl implements   TicketDao{
	@PersistenceContext
	EntityManager em;
	@Override
	public Ticket save(Ticket ticket) {
		// TODO Auto-generated method stub
		String sql="select t from Technician t where t.technicianCategory= :technicianCategory";
		TypedQuery<Technician> query=em.createQuery( sql,Technician.class);
	   query.setParameter("technicianCategory", ticket.getCategoryName());
	   Technician t=query.getSingleResult();
	   List<Ticket> tlist=t.getTicket();
	   tlist.add(ticket);
	   t.setTicket(tlist);
	   em.merge(t);
	 // em.getTransaction().commit();
	   return ticket;
	}

	@Override
	public Ticket findticketById(int id) {
		// TODO Auto-generated method stub
		String sql="select tic from Ticket tic  where tic.id=:id";
		TypedQuery<Ticket> query=em.createQuery(sql,Ticket.class);
		query.setParameter("id", id);
		Ticket tidsearch=query.getSingleResult();
		//em.getTransaction().commit();
		return tidsearch;
	}

	
	
	
}