package com.cg.ticketmanagementsystemmvcspring.dao;

import java.util.List;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;


public interface TechnicianDao {
	public Technician  save(Technician technician);
	List<Technician> findTechnicianByCategory(String techniciancategory) ;
	public List<Technician> showAlltechniciancategory() ;

}
