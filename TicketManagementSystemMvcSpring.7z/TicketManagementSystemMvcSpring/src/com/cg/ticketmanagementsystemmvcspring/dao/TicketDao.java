package com.cg.ticketmanagementsystemmvcspring.dao;

import com.cg.ticketmanagementsystemmvcspring.dto.Ticket;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;

public interface TicketDao {

	public Ticket save(Ticket ticket) ;
	//List<Ticket> findById(int id) throws CategoryNotFoundException;
	
	public Ticket findticketById(int id) ;
}
