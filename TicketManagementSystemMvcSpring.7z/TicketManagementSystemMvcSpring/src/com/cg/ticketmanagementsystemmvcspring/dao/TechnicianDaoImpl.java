package com.cg.ticketmanagementsystemmvcspring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ticketmanagementsystemmvcspring.dto.Technician;
import com.cg.ticketmanagementsystemmvcspring.exception.CategoryNotFoundException;


@Repository
public class TechnicianDaoImpl implements TechnicianDao {
	
	@PersistenceContext
	EntityManager em;

	@Override
	public Technician save(Technician technician) {
		// TODO Auto-generated method stub
		em.persist(technician);
		em.flush();
		//em.merge(technician);
	//	em.getTransaction().commit();
		return technician;
	
	}

	@Override
	public List<Technician> findTechnicianByCategory(String techniciancategory) {
		// TODO Auto-generated method stub
		String sql="select t from Technician t  where t.technicianCategory=:technicianCategory";
		TypedQuery<Technician> query=em.createQuery(sql,Technician.class);
		query.setParameter("technicianCategory", techniciancategory);
		List<Technician> tcsearch=query.getResultList();
		
		//em.getTransaction().commit();
		return tcsearch;
	}

	@Override
	public List<Technician> showAlltechniciancategory() {
		// TODO Auto-generated method stub
		String qStr="SELECT tech FROM Technician tech ";
	      TypedQuery<Technician> query=em.createQuery(qStr,Technician.class);
		  List<Technician> mylist=query.getResultList();
			return mylist;     
	}

}

