package com.cg.ticketmanagementsystemmvcspring.exception;

public class CategoryNotFoundException extends Exception{

	public CategoryNotFoundException() {
		super();

	}
}
